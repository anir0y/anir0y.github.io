<?php
$con= new mysqli("mysql", "root", ".sweetpwd.","my_db");
if($con->connect_error){
    die("Connection failed: ".$con->connect_error);
}
$sql = "SELECT name FROM users";
$result = $con->query($sql);
 
if ($result->num_rows > 0) {
	// output data of each row
	while($row = $result->fetch_assoc()) {
		echo $row['name']."<br></br>";
	}
} else {
	echo "0 results";
}
$con->close();