#include "CommandHandler.hpp"

#include <iostream>
#include <sstream>
#include <vector>

std::string generic_handler(std::string command, std::vector<std::string> params)
{
    std::stringstream output;
    
    output << "The command [" << command << "] is not implemented.";
    
    std::cerr << "\033[1;31m" << output.str() << "\033[0m" << std::endl;
    return output.str();
}

CommandHandler::CommandHandler(AbstractCommunicator *communicator)
{
    this->communicator = communicator;
    this->default_handler = generic_handler;
}

CommandHandler::CommandHandler(AbstractCommunicator *communicator, std::function<std::string(std::string, std::vector<std::string>)> default_handler)
{
    this->communicator = communicator;
    this->default_handler = default_handler;
}

CommandHandler::~CommandHandler()
{
}

std::function<std::string(std::vector<std::string>)>& CommandHandler::operator[](std::string command)
{
    if (function_map.find(command) == function_map.end())
    {
        function_map[command] = std::bind(this->default_handler, command, std::placeholders::_1);
    }
    
    return function_map[command];
}

void CommandHandler::run()
{
    std::vector<std::string> params;
    std::string request, response;
    while (true)
    {
        request = communicator->getRequest();
        response = this->operator[](request)(params);
        communicator->sendResponse(response);
    }
}
