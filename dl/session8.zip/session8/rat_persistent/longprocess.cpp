#include <iostream>
#include <thread>
#include <chrono>

using namespace std::chrono_literals;

int main()
{
    while (true)
    {
        std::cout << "A" << std::flush;
        std::this_thread::sleep_for(1s);
    }
    return 0;
}
