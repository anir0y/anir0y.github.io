#ifndef _COMMAND_HANDLER_
#define _COMMAND_HANDLER_

#include <functional>
#include <string>
#include <unordered_map>
#include <vector>

#include "Communicator.hpp"

class CommandHandler
{
private:
    std::unordered_map<std::string, std::function<std::string(std::vector<std::string>)>> function_map;
    std::function<std::string(std::string, std::vector<std::string>)> default_handler;
    AbstractCommunicator *communicator;
protected:
public:
    CommandHandler(AbstractCommunicator *communicator);
    CommandHandler(AbstractCommunicator *communicator, std::function<std::string(std::string, std::vector<std::string>)> default_handler);
    ~CommandHandler();
    std::function<std::string(std::vector<std::string>)>& operator[](std::string command);
    void run();
};

#endif
