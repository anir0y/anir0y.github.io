#include <cstdio>
#include <iostream>

#include "TcpControlServer.hpp"
#include "CommandHandler.hpp"

std::string help(std::vector<std::string> params)
{
    return std::string("This is help");
}

std::string hello(std::vector<std::string> params)
{
    return std::string("This is hello world");
}

std::string shell(std::string command, std::vector<std::string> params)
{
    std::string response = "";
    
    command.append(" 2>&1");
    FILE* fp = popen(command.c_str(), "r");
    
    char buffer[4096];
    memset(buffer, 0, 4096);
    
    while (fread(buffer, 1, 4096, fp) > 0)
    {
        response.append(buffer);
        memset(buffer, 0, 4096);
    }
    
    pclose(fp);
    
    if (response == "")
        response = "[+] Command completed\n";
    
    return response;
}

int main(int argc, char** argv)
{
    std::string port = "";
    TcpControlServer service(port);
    std::thread t = service.startListener();
    
    CommandHandler dispatcher(&service, shell);
    
    // attach command handlers here
    //dispatcher["help"] = help;
    //dispatcher["hello"] = hello;
    
    dispatcher.run();
    
    std::cout << "Joining the thread" << std::endl;
    t.join();
    
    return 0;
}
