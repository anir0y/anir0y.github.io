#include <iostream>
#include <cstring> /* memset() */
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <netdb.h>
#include <csignal>

#define BACKLOG  10      /* Passed to listen() */
#define BUF_SIZE 4096    /* Buffer for  transfers */

unsigned int transfer(int from, int to)
{
    char buf[BUF_SIZE];
    unsigned int disconnected = 0;
    size_t bytes_read, bytes_written;
    bytes_read = read(from, buf, BUF_SIZE);
    if (bytes_read == 0) {
        disconnected = 1;
    }
    else {
        bytes_written = write(to, buf, bytes_read);
        if (bytes_written == -1) {
            disconnected = 1;
        }
    }
    return disconnected;
}

void handle(int client1, int client2)
{
    unsigned int disconnected = 0;
    fd_set set;
    unsigned int max_sock;

    if (client1 > client2) {
        max_sock = client1;
    }
    else {
        max_sock = client2;
    }

    while (!disconnected) {
        FD_ZERO(&set);
        FD_SET(client1, &set);
        FD_SET(client2, &set);
        if (select(max_sock + 1, &set, NULL, NULL, NULL) == -1) {
            std::cerr << "select";
            break;
        }
        if (FD_ISSET(client1, &set)) {
            disconnected = transfer(client1, client2);
        }
        if (FD_ISSET(client2, &set)) {
            disconnected = transfer(client2, client1);
        }
    }
}

void handle(int client, const char *remote_host, const char *remote_port)
{
    struct addrinfo hints, *res;
    int server = -1;
    unsigned int disconnected = 0;
    fd_set set;
    unsigned int max_sock;

    /* Get the address info */
    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    if (getaddrinfo(remote_host, remote_port, &hints, &res) != 0) {
        std::cerr << "getaddrinfo";
        close(client);
        return;
    }

    /* Create the socket */
    server = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    if (server == -1) {
        std::cerr<<"socket";
        close(client);
        return;
    }

    /* Connect to the host */
    if (connect(server, res->ai_addr, res->ai_addrlen) == -1) {
        std::cerr << "connect";
        close(client);
        return;
    }

    if (client > server) {
        max_sock = client;
    }
    else {
        max_sock = server;
    }

    /* Main transfer loop */
    while (!disconnected) {
        FD_ZERO(&set);
        FD_SET(client, &set);
        FD_SET(server, &set);
        if (select(max_sock + 1, &set, NULL, NULL, NULL) == -1) {
            std::cerr << "select";
            break;
        }
        if (FD_ISSET(client, &set)) {
            disconnected = transfer(client, server);
        }
        if (FD_ISSET(server, &set)) {
            disconnected = transfer(server, client);
        }
    }
    close(server);
    close(client);
}

int forward_proxy(const char* local_host, const char* local_port, const char* remote_host, const char* remote_port)
{
    int sock;
    struct addrinfo hints, *res;
    int reuseaddr = 1; /* True */

    /* Get the address info */
    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    if (getaddrinfo(local_host, local_port, &hints, &res) != 0) {
        std::cerr << "getaddrinfo";
        return 1;
    }

    /* Create the socket */
    sock = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    if (sock == -1) {
        std::cerr << "socket";
        freeaddrinfo(res);
        return 1;
    }

    /* Enable the socket to reuse the address */
    if (setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &reuseaddr, sizeof(int)) == -1) {
        std::cerr << "setsockopt";
        freeaddrinfo(res);
        return 1;
    }

    /* Bind to the address */
    if (bind(sock, res->ai_addr, res->ai_addrlen) == -1) {
        std::cerr << "bind";
        freeaddrinfo(res);
        return 1;
    }

    /* Listen */
    if (listen(sock, BACKLOG) == -1) {
        std::cerr << "listen";
        freeaddrinfo(res);
        return 1;
    }

    freeaddrinfo(res);

    /* Ignore broken pipe signal */
    signal(SIGPIPE, SIG_IGN);

    /* Main loop */
    while (true) {
        socklen_t size = sizeof(struct sockaddr_in);
        struct sockaddr_in their_addr;
        int newsock = accept(sock, (struct sockaddr*)&their_addr, &size);

        if (newsock == -1) {
            std::cerr << "accept" << std::flush;
            close(sock);
            return -1;
        }
        else {
            std::cout << "Got a connection from " << inet_ntoa(their_addr.sin_addr) << " on port "
                   << htons(their_addr.sin_port) << std::endl;
            handle(newsock, remote_host, remote_port);
        }
    }

    close(sock);
    return 0;
}

int reverse_proxy(const char* reverse_host, const char* reverse_port, const char* remote_host, const char* remote_port)
{
    struct addrinfo hints, *res;
    int server = -1;

    /* Get the address info */
    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    if (getaddrinfo(reverse_host, reverse_port, &hints, &res) != 0) {
        std::cerr << "getaddrinfo";
        return -1;
    }

    /* Create the socket */
    server = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    if (server == -1) {
        std::cerr<<"socket";
        return -2;
    }

    /* Connect to the host */
    if (connect(server, res->ai_addr, res->ai_addrlen) == -1) {
        std::cerr << "connect";
        return -3;
    }

    while (true)
    {
        handle(server, remote_host, remote_port);
    }
    close(server);
    return 0;
}

int handler_proxy(const char* local_host1, const char* local_port1, const char* local_host2, const char* local_port2)
{
    int sock1, sock2;
    int reuseaddr = 1;
    struct addrinfo hints1, hints2, *res1, *res2;

    memset(&hints1, 0, sizeof hints1);
    hints1.ai_family = AF_INET;
    hints1.ai_socktype = SOCK_STREAM;
    if (getaddrinfo(local_host1, local_port1, &hints1, &res1) != 0) {
        std::cerr << "getaddrinfo";
        return -1;
    }

    memset(&hints2, 0, sizeof hints2);
    hints2.ai_family = AF_INET;
    hints2.ai_socktype = SOCK_STREAM;
    if (getaddrinfo(local_host2, local_port2, &hints2, &res2) != 0) {
        std::cerr << "getaddrinfo";
        return -1;
    }

    sock1 = socket(res1->ai_family, res1->ai_socktype, res1->ai_protocol);
    if (sock1 == -1) {
        std::cerr<<"socket";
        return -2;
    }

    /* Enable the socket to reuse the address */
    if (setsockopt(sock1, SOL_SOCKET, SO_REUSEADDR, &reuseaddr, sizeof(int)) == -1) {
        std::cerr << "setsockopt sock1";
        freeaddrinfo(res1);
        return 1;
    }

    /* Bind to the address */
    if (bind(sock1, res1->ai_addr, res1->ai_addrlen) == -1) {
        std::cerr << "bind";
        freeaddrinfo(res1);
        return 1;
    }

    /* Listen */
    if (listen(sock1, BACKLOG) == -1) {
        std::cerr << "listen";
        freeaddrinfo(res1);
        return 1;
    }

    sock2 = socket(res2->ai_family, res2->ai_socktype, res2->ai_protocol);
    if (sock2 == -1) {
        std::cerr<<"socket";
        return -2;
    }

    if (setsockopt(sock2, SOL_SOCKET, SO_REUSEADDR, &reuseaddr, sizeof(int)) == -1) {
        std::cerr << "setsockopt sock2";
        freeaddrinfo(res2);
        return 1;
    }

    /* Bind to the address */
    if (bind(sock2, res2->ai_addr, res2->ai_addrlen) == -1) {
        std::cerr << "bind";
        freeaddrinfo(res2);
        return 1;
    }

    /* Listen */
    if (listen(sock2, BACKLOG) == -1) {
        std::cerr << "listen";
        freeaddrinfo(res1);
        return 1;
    }

    freeaddrinfo(res1);
    freeaddrinfo(res2);

    /* Main loop */
    while (true) {
        socklen_t size1 = sizeof(struct sockaddr_in);
        struct sockaddr_in their_addr1;

        socklen_t size2 = sizeof(struct sockaddr_in);
        struct sockaddr_in their_addr2;
        int newsock1 = accept(sock1, (struct sockaddr*)&their_addr1, &size1);
        int newsock2 = accept(sock2, (struct sockaddr*)&their_addr2, &size2);

        if (newsock1 == -1 || newsock2 == -1) {
            std::cerr << "accept" << std::flush;
            close(sock1);
            return -1;
        }
        else {
            handle(newsock1, newsock2);
        }
    }

    return 0;
}

int main(int argc, char **argv)
{
    const char *local_host, *local_port, *remote_host, *remote_port;

    /* Get the local and remote hosts and ports from the command line */
    if (argc < 6) {
        std::cerr << "Usage: " << argv[0] << " forward <local_host> <local_port> <remote_host> <remote_port>"
        << std::endl;
        std::cerr << "Usage: " << argv[0] << " reverse <reverse_host> <reverse_port> <remote_host> <remote_port>"
        << std::endl;
        std::cerr << "Usage: " << argv[0] << " handler <local_host1> <local_port1> <local_host2> <local_port2>"
        << std::endl;
        return 1;
    }
    local_host = argv[2];
    local_port = argv[3];
    remote_host = argv[4];
    remote_port = argv[5];

    if (strcmp(argv[1], "forward") == 0)
        forward_proxy(local_host, local_port, remote_host, remote_port);
    else if (strcmp(argv[1], "reverse") == 0)
        reverse_proxy(local_host, local_port, remote_host, remote_port);
    else if (strcmp(argv[1], "handler") == 0)
        handler_proxy(local_host, local_port, remote_host, remote_port);

    return 0;
}