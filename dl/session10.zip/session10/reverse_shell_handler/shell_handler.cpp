#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netdb.h>
#include <cstdio>
#include <cstring>
#include <unistd.h>

#include <iostream>
#include <fstream>
#include <cerrno>
#include <string>

int interactive_handler()
{
    char str[4096];
    int listen_fd, comm_fd, max_clients = 1;
    int fd_stdin = 0, fd_stdout = 1;

    fd_set readfds, writefds;

    timeval tv;

    struct sockaddr_in servaddr;

    listen_fd = socket(AF_INET, SOCK_STREAM, 0);

    bzero( &servaddr, sizeof(servaddr));

    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htons(INADDR_ANY);
    servaddr.sin_port = htons(8000);

    bind(listen_fd, (struct sockaddr *) &servaddr, sizeof(servaddr));
    listen(listen_fd, 10);
    comm_fd = accept(listen_fd, (struct sockaddr*) NULL, NULL);

    while(true)
    {
        FD_ZERO(&readfds);
        FD_ZERO(&writefds);
        FD_SET(comm_fd, &readfds);
        FD_SET(fd_stdin, &readfds);
        FD_SET(comm_fd, &writefds);

        tv.tv_sec = 1;
        tv.tv_usec = 0;

        int activity = select(comm_fd + 1, &readfds, &writefds, NULL, NULL);

        if ((activity < 0) && (errno!=EINTR))
        {
            printf("select error");
        }

        else if (FD_ISSET(fd_stdin, &readfds))
        {
            // we timed out, time to write something here?
            //std::cout << "Output: " << output << std::endl;
            //output = "";

            bzero( str, 4096);
            read(fd_stdin,str,4096);

            write(comm_fd, str, strlen(str) +1);
        }

        if (FD_ISSET(comm_fd, &readfds))
        {
            bzero( str, 4096);
            read(comm_fd,str,4096);
            //output.append(str, strlen(str));
            write(fd_stdout, str, strlen(str) +1);
            //write(comm_fd, str, strlen(str)+1);
        }
    }
}

int main(int argc, char** argv)
{
    if (argc < 2)
    {
        return interactive_handler();
    } else
    {
        std::string command(argv[1]);
        char str[4096];
        int listen_fd, comm_fd;

        struct sockaddr_in servaddr;

        listen_fd = socket(AF_INET, SOCK_STREAM, 0);

        bzero( &servaddr, sizeof(servaddr));

        servaddr.sin_family = AF_INET;
        servaddr.sin_addr.s_addr = htons(INADDR_ANY);
        servaddr.sin_port = htons(8000);

        bind(listen_fd, (struct sockaddr *) &servaddr, sizeof(servaddr));
        listen(listen_fd, 10);
        comm_fd = accept(listen_fd, (struct sockaddr*) NULL, NULL);

        // it is time to write commands here

        std::ifstream infile(command);
        std::string line;

        while (std::getline(infile, line))
        {
            line.append("\n");
            size_t bytes_written, total = 0;
            do {
                bytes_written = write(comm_fd, line.c_str() + total, line.length() - total);
                total += bytes_written;
            } while (total < line.length());
            sleep(5);
        }
        infile.close();
    }

    int val;
    //std::cin >> val;
    return 0;
}