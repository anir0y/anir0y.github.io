//
// Created by adhokshajmishra on 25/4/20.
//
#include <iostream>
#include <sys/mman.h>
#include <unistd.h>
#include <vector>
#include <algorithm>
#include <array>
#include <cstdint>
#include <numeric>

void secret()
{
    for (int i = 0; i < 10; ++i)
    {
        std::cout << "Try a breakpoint at secret()" << std::endl;
    }
}

std::array<std::uint_fast32_t, 256> generate_crc_lookup_table() noexcept
{
    auto const reversed_polynomial = std::uint_fast32_t{0xEDB88320uL};

    // This is a function object that calculates the checksum for a value,
    // then increments the value, starting from zero.
    struct byte_checksum
    {
        std::uint_fast32_t operator()() noexcept
        {
            auto checksum = static_cast<std::uint_fast32_t>(n++);

            for (auto i = 0; i < 8; ++i)
                checksum = (checksum >> 1) ^ ((checksum & 0x1u) ? reversed_polynomial : 0);

            return checksum;
        }

        unsigned n = 0;
    };

    auto table = std::array<std::uint_fast32_t, 256>{};
    std::generate(table.begin(), table.end(), byte_checksum{});

    return table;
}

template <typename InputIterator>
std::uint_fast32_t crc(InputIterator first, InputIterator last)
{
    // Generate lookup table only on first use then cache it - this is thread-safe.
    static auto const table = generate_crc_lookup_table();

    // Calculate the checksum - make sure to clip to 32 bits, for systems that don't
    // have a true (fast) 32-bit type.
    return std::uint_fast32_t{0xFFFFFFFFuL} &
           ~std::accumulate(first, last,
                            ~std::uint_fast32_t{0} & std::uint_fast32_t{0xFFFFFFFFuL},
                            [](std::uint_fast32_t checksum, std::uint_fast8_t value)
                            { return table[(checksum ^ value) & 0xFFu] ^ (checksum >> 8); });
}

bool isFunctionPatched(const unsigned char *func, const size_t& machine_code_size, const std::uint32_t& checksum)
{
    bool result = true;

    std::vector<unsigned char> machine_code;

    for (auto i = 0; i < machine_code_size; ++i)
    {
        machine_code.push_back(*(func+i));
    }

    uint32_t value = crc(machine_code.begin(), machine_code.end());
    //std::cerr << "Original checksum = " << checksum << "\nCalculated checksum = " << value << std::endl;

    result = (value != checksum);
    return result;
}

bool unpatchFunction(unsigned char *func, const std::vector<unsigned char>& machine_code)
{
    bool result = false;

    long pagesize = sysconf(_SC_PAGESIZE);
    unsigned long page_start = (unsigned long)func & ~(pagesize - 1);

    if (mprotect((void*)page_start, pagesize, PROT_READ | PROT_WRITE | PROT_EXEC) != 0)
    {
        std::cerr << "mprotect() failed" << std::endl;
        return false;
    }

    for (auto i = 0; i < machine_code.size(); ++i)
    {
        if (*(func + i) != machine_code[i]) {
            *(func + i) = machine_code[i];
            result = true;
        }
    }

    return result;
}

int main()
{
    auto *ptr_secret = (unsigned char*)secret;
    std::vector<unsigned char> machine_code = {0x55,
                                               0x48, 0x89, 0xe5,
                                               0x48, 0x83, 0xec, 0x10,
                                               0xc7, 0x45, 0xfc, 0x00, 0x00, 0x00, 0x00,
                                               0x83, 0x7d, 0xfc, 0x09,
                                               0x7f, 0x2e,
                                               0x48, 0x8d, 0x35, 0xd6, 0x1d, 0x00, 0x00,
                                               0x48, 0x8d, 0x3d, 0x83, 0x4e, 0x00, 0x00,
                                               0xe8, 0x4e, 0xfe, 0xff, 0xff,
                                               0x48, 0x89, 0xc2,
                                               0x48, 0x8b, 0x05, 0x84, 0x4d, 0x00, 0x00,
                                               0x48, 0x89, 0xc6,
                                               0x48, 0x89, 0xd7,
                                               0xe8, 0x59, 0xfe, 0xff, 0xff,
                                               0x83, 0x45, 0xfc, 0x01,
                                               0xeb, 0xcc,
                                               0x90,
                                               0xc9,
                                               0xc3};

    /*
    for (auto &offset : offsets)
    {
        original_bytes.push_back(*(ptr_secret + offset));
    }

    std::ios_base::fmtflags f(std::cout.flags());

    for (auto &raw_byte : original_bytes)
    {
        std::cout << "0x" << std::hex << static_cast<unsigned short>(raw_byte) << ", ";
    }

    std::cout.flags(f);
    std::cout<<std::flush;
    */

    uint32_t checksum = 0x17d2344;
    //size_t func_size = machine_code.size();
    size_t func_size = 70;
    //uint32_t checksum = crc(machine_code.begin(), machine_code.end());
    //std::cerr << "CRC Checksum = " << checksum << " Size = " << func_size << std::endl;
    if (isFunctionPatched(ptr_secret, func_size, checksum)){
        std::cerr << "Function patching detected" << std::endl;
        if(unpatchFunction(ptr_secret, machine_code)) {
            std::cerr << "Function has been unpatched" << std::endl;
            secret();
        }
    }
    else
        secret();
    return 0;
}