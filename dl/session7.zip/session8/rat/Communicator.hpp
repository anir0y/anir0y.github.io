#ifndef _COMMUNICATOR_HPP_
#define _COMMUNICATOR_HPP_

class AbstractCommunicator
{
public:
    virtual ~AbstractCommunicator() {}
    virtual std::string getRequest() = 0;
    virtual void sendResponse(std::string response) = 0;
};

#endif
