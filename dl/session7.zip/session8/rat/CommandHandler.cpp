#include "CommandHandler.hpp"

#include <iostream>
#include <sstream>
#include <vector>

CommandHandler::CommandHandler(AbstractCommunicator *communicator)
{
    this->communicator = communicator;
}

CommandHandler::~CommandHandler()
{
}

std::string default_handler(std::string command, std::vector<std::string> params)
{
    std::stringstream output;
    
    output << "The command [" << command << "] is not implemented.";
    
    std::cerr << "\033[1;31m" << output.str() << "\033[0m" << std::endl;
    return output.str();
}

std::function<std::string(std::vector<std::string>)>& CommandHandler::operator[](std::string command)
{
    if (function_map.find(command) == function_map.end())
    {
        function_map[command] = std::bind(default_handler, command, std::placeholders::_1);
    }
    
    return function_map[command];
}

void CommandHandler::run()
{
    std::vector<std::string> params;
    std::string request, response;
    while (true)
    {
        request = communicator->getRequest();
        response = this->operator[](request)(params);
        communicator->sendResponse(response);
    }
}
