#include "CommandHandler.hpp"
#include <iostream>
#include <vector>

std::string testfunction1(std::vector<std::string> params)
{
    std::cerr << "testfunction1 called." << std::endl;
    return std::string("");
}

std::string testfunction2(std::vector<std::string> params)
{
    std::cerr << "testfunction2 called." << std::endl;
    return std::string("");
}

int main()
{
    std::vector<std::string> params = {"foo", "bar"};
    std::vector<std::string> commands = {"help", "random", "whoami", "deadbeef"};
    
    CommandHandler dispatcher(nullptr);
    
    dispatcher["help"] = testfunction1;
    dispatcher["whoami"] = testfunction2;
    
    for (auto &i : commands)
    {
        auto f = dispatcher[i];
        f(params);
    }
    
    return 0;
}
