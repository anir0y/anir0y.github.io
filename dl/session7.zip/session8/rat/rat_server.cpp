#include <iostream>

#include "TcpControlServer.hpp"
#include "CommandHandler.hpp"

std::string help(std::vector<std::string> params)
{
    return std::string("This is help");
}

std::string hello(std::vector<std::string> params)
{
    return std::string("This is hello world");
}

int main(int argc, char** argv)
{
    std::string port = "";
    TcpControlServer service(port);
    std::thread t = service.startListener();
    
    CommandHandler dispatcher(&service);
    
    // attach command handlers here
    dispatcher["help"] = help;
    dispatcher["hello"] = hello;
    
    dispatcher.run();
    
    std::cout << "Joining the thread" << std::endl;
    t.join();
    
    return 0;
}
