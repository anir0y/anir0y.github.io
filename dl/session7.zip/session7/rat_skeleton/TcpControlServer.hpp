#ifndef _TCP_CONTROL_SERVER
#define _TCP_CONTROL_SERVER

#include <cstdlib>
#include <unistd.h>
#include <errno.h>
#include <cstring>
#include <sys/socket.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <poll.h>
#include <ifaddrs.h>
#include <string>

#include <mutex>
#include <thread>

#include <mbedtls/entropy.h>
#include <mbedtls/ctr_drbg.h>
#include <mbedtls/net.h>

struct packet {
    unsigned char *buffer;
    int size;
};

struct ssl_conn {
    mbedtls_net_context conn_fd;
    mbedtls_ssl_context ssl_fd;
    struct ssl_conn *next;
};

class TcpControlServer
{
private:
    int i, ret;
    int had_output = 0;
    std::string empty_return = "[*] Command completed\n";
    FILE *fp;
    std::string env_port;
    std::string default_port= "12345";
    
    std::string request, response;

    struct pollfd fds[64];
    int    nfds = 1, current_size = 0;
    struct ssl_conn *listen_conn = NULL;
    struct ssl_conn *client_conn = NULL;
    struct ssl_conn *clean_helper = NULL;
    struct packet compress;
    struct ifaddrs *ifa = NULL;
    struct ifaddrs *tmp = NULL;
    struct sockaddr_in *pAddr = NULL;

    //mbedtls
    mbedtls_entropy_context entropy;
    mbedtls_ctr_drbg_context ctr_drbg;
    mbedtls_ssl_config conf;
    mbedtls_x509_crt srvcert;
    mbedtls_pk_context pkey;
    
    // mutexes
    std::mutex read_mutex, write_mutex;
    
    //status
    bool isResponse;
    
protected:
    void add_client(struct ssl_conn **head, struct ssl_conn **client_conn);
    void client_disconnect(struct ssl_conn **head, struct pollfd *fds, int fd, int *nfds);
    void cleanup();
    int startListenerThread();

public:
    TcpControlServer(std::string bind_port = "");
    ~TcpControlServer();
    std::thread startListener();
    void sendResponse(std::string response);
    std::string getRequest();
};

#endif
