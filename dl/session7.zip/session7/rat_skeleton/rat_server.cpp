#include <iostream>

#include "TcpControlServer.hpp"

int main(int argc, char** argv)
{
    std::string port = "";
    TcpControlServer service(port);
    std::thread t = service.startListener();
    
    while (true)
    {
        std::string request = service.getRequest();
        
        std::cout << "Request: " << request << std::endl;
        
        service.sendResponse(request);
    }
    
    std::cout << "Joining the thread" << std::endl;
    t.join();
    
    return 0;
}
