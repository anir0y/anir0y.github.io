#include "plugin_base.hpp"
#include "pluginloader.hpp"
#include "httplib.hpp"

#include <dlfcn.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/mman.h>
#include <vector>
#include <functional>
#include <iostream>
#include <sstream>

typedef void*(*module_init)();
typedef void(*module_exit)(void*);

std::vector<std::string> split_string(const std::string& str,
                                      const std::string& delimiter)
{
    std::vector<std::string> strings;

    std::string::size_type pos = 0;
    std::string::size_type prev = 0;
    while ((pos = str.find(delimiter, prev)) != std::string::npos)
    {
        strings.push_back(str.substr(prev, pos - prev));
        prev = pos + delimiter.size();
    }

    // To get the last substring (or only, if delimiter is not found)
    strings.push_back(str.substr(prev));

    return strings;
}

PluginLoader::PluginLoader(std::string path)
{
    if (path == "")
    {
        this->module_root = "http://localhost/";
    }
    else if (path.back() != '/')
    {
        this->module_root = path + "/";
    }
    else
    {
        this->module_root = path;
    }

    this->load();
}

void PluginLoader::load()
{
    // load module inventory from server
    HTTPBasicRequest req;
    req.SetURL(this->module_root + "inventory");
    
    std::string module_list = req.GetResponseString();
    std::vector<std::string> modules = split_string(module_list, "\n");
    
    for (const auto &entry : modules)
    {
        if (entry == "")
            continue;
        
        int fd = memfd_create(entry.c_str(), 1);
        
        req.SetURL(this->module_root + entry);
        
        if (req.DownloadFile(fd))
        {
            std::stringstream ss;
            ss << "/proc/" << std::to_string(getpid()) << "/fd/" << std::to_string(fd);
            
            std::string path = ss.str();
            
            void* handle = dlopen(path.c_str(), RTLD_LAZY);

            if (!handle)
            {
                std::cerr << "[" << entry << "] dlerror: " << dlerror() << std::endl;
                failed_module_list.push_back(entry);
                // we do not close handle here, because it was not acquired at first place
                // we still have to close the fd
                close(fd);
                continue;
            }
            else
            {
                module_init minit = reinterpret_cast<module_init> (dlsym(handle, "module_init"));
                if (!minit)
                {
                    dlclose(handle);
                    close(fd);
                    failed_module_list.push_back(entry);
                    continue;
                }
                AbstractPlugin *plugin = reinterpret_cast<AbstractPlugin*>(minit());
                if (plugin->load() == 0)
                {
                    std::string plugin_name = plugin->name();
                    loaded_module_list.push_back(plugin_name);
                    handles.push_back(handle);
                    file_descriptors.push_back(fd);
                    plugins.push_back(plugin);
                }
                else
                {
                    plugin->unload();
                    dlclose(handle);
                    close(fd);
                    failed_module_list.push_back(entry);
                }
            }
        }
        else
        {
            close(fd);
        }
    }
}

void PluginLoader::unload()
{
    for (unsigned int i = 0; i < handles.size(); ++i)
    {
        module_exit mexit = reinterpret_cast<module_exit> (dlsym(handles[i], "module_exit"));
        if (mexit)
        {
            AbstractPlugin *plugin = reinterpret_cast<AbstractPlugin*>(plugins[i]);
            plugin->unload();
            mexit(plugins[i]);
        }
        dlclose(handles[i]);
    }
    
    for (int fd : file_descriptors)
    {
        close(fd);
    }

    handles.clear();
    plugins.clear();
    file_descriptors.clear();
    loaded_module_list.clear();
    failed_module_list.clear();
}

std::string PluginLoader::launch_module(unsigned int module_index, const std::string& parameter)
{
    AbstractPlugin *plugin = reinterpret_cast<AbstractPlugin*>(plugins[module_index]);
    std::string result = plugin->run(parameter);
    return result;
}

PluginLoader::~PluginLoader()
{
    this->unload();
}

std::vector<std::string> PluginLoader::failed_modules()
{
    return failed_module_list;
}

std::vector<std::string> PluginLoader::loaded_modules()
{
    return loaded_module_list;
}
