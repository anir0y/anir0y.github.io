#ifndef _HTTP_LIB_
#define _HTTP_LIB_

#include <curl/curl.h>
#include <string>

class HTTPBasicRequest
{
private:
    std::string url;
    std::string response;
    CURL *curl_handle;
    CURLcode res;
public:
    HTTPBasicRequest(std::string url = "");
    ~HTTPBasicRequest();
    void SetURL(std::string new_url);
    std::string GetResponseString();
    bool DownloadFile(std::string path);
    bool DownloadFile(int fd);
};

#endif
