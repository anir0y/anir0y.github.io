#include "httplib.hpp"

#include <iostream>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

std::string temp_response = "";
size_t download_size = 0;

static size_t WriteMemoryCallback(void *contents, size_t size, size_t nmemb, void *userp)
{
    size_t realsize = size * nmemb;
    std::string *ptr = reinterpret_cast<std::string*>(userp);
    ptr->append(reinterpret_cast<char*>(contents), realsize);
    return realsize;
}

size_t WriteFileCallback (void *contents, size_t size, size_t nmemb, int shm_fd)
{
    size_t realsize = size * nmemb;
    int bytes = write(shm_fd, contents, realsize);
	if (bytes < 0)
    {
        std::cerr << "[-] Could not write file :'(" << std::endl;
		return 0;
	}
	download_size += realsize;
	
    return bytes;
}

HTTPBasicRequest::HTTPBasicRequest(std::string url)
{
    if (url != "")
        this->url = url;
}

HTTPBasicRequest::~HTTPBasicRequest()
{
}

void HTTPBasicRequest::SetURL(std::string new_url)
{
    if (new_url != "")
        this->url = new_url;
}

std::string HTTPBasicRequest::GetResponseString()
{
    temp_response = "";
    curl_global_init(CURL_GLOBAL_ALL);
    curl_handle = curl_easy_init();
    
    curl_easy_setopt(curl_handle, CURLOPT_URL, this->url.c_str());
    curl_easy_setopt(curl_handle, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(curl_handle, CURLOPT_SSL_VERIFYHOST, 0L);
    curl_easy_setopt(curl_handle, CURLOPT_USERAGENT, "curl-agent/1.0");
    curl_easy_setopt(curl_handle, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
    curl_easy_setopt(curl_handle, CURLOPT_WRITEDATA, (void *)&temp_response);
    
    res = curl_easy_perform(curl_handle);
    if(res != CURLE_OK)
    {
        std::cerr << "curl_easy_perform() failed: " << curl_easy_strerror(res) << std::endl;
    }
    else
    {
        //std::cout << temp_response.length() << " bytes received" << std::endl;
    }
    
    curl_easy_cleanup(curl_handle);
    curl_global_cleanup();
    
    this->response = temp_response;
    return this->response;
}

bool HTTPBasicRequest::DownloadFile(std::string path)
{
    int fd = open(path.c_str(), O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);
    return DownloadFile(fd);
}

bool HTTPBasicRequest::DownloadFile(int fd)
{
    download_size = 0;
    curl_global_init(CURL_GLOBAL_ALL);
    curl_handle = curl_easy_init();
    
    curl_easy_setopt(curl_handle, CURLOPT_URL, this->url.c_str());
    curl_easy_setopt(curl_handle, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(curl_handle, CURLOPT_SSL_VERIFYHOST, 0L);
    curl_easy_setopt(curl_handle, CURLOPT_USERAGENT, "curl-agent/1.0");
    curl_easy_setopt(curl_handle, CURLOPT_WRITEFUNCTION, WriteFileCallback);
    curl_easy_setopt(curl_handle, CURLOPT_WRITEDATA, fd);
    
    res = curl_easy_perform(curl_handle);
    if(res != CURLE_OK)
    {
        std::cerr << "curl_easy_perform() failed: " << curl_easy_strerror(res) << std::endl;
        return false;
    }
    else
    {
        //std::cout << download_size << " bytes received" << std::endl;
    }
    
    curl_easy_cleanup(curl_handle);
    curl_global_cleanup();
    return true;
}
