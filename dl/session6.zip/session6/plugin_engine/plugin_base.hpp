#ifndef PLUGIN_BASE_HPP
#define PLUGIN_BASE_HPP

#include <functional>
#include <string>
#include <unordered_map>

class AbstractPlugin
{
public:
    virtual ~AbstractPlugin() {}
    virtual int load() = 0;
    virtual int unload() = 0;
    virtual std::string name() = 0;
    virtual std::string run(const std::string& parameter = "") = 0;
};

#endif // PLUGIN_BASE_HPP
