#include "plugin_base.hpp"
#include "pluginloader.hpp"

#include <dlfcn.h>
#include <functional>
#include <iostream>

typedef void*(*module_init)();
typedef void(*module_exit)(void*);

PluginLoader::PluginLoader(std::string path)
{
    if (path == "") {
        this->module_root = "./";
    }
    else {
        this->module_root = path;
    }

    this->load();
}

void PluginLoader::load()
{
    for (const auto &entry : std::filesystem::directory_iterator(this->module_root))
    {
        if (entry.path().extension() == ".so")
        {
            void* handle = dlopen(entry.path().c_str(), RTLD_LAZY);

            if (!handle)
            {
                std::cerr << "dlerror: " << dlerror() << std::endl;
                failed_module_list.push_back(entry.path().string());
                // we do not close handle here, because it was not acquired at first place
                continue;
            }
            else {
                module_init minit = reinterpret_cast<module_init> (dlsym(handle, "module_init"));
                if (!minit)
                {
                    dlclose(handle);
                    failed_module_list.push_back(entry.path().string());
                    continue;
                }
                AbstractPlugin *plugin = reinterpret_cast<AbstractPlugin*>(minit());
                if (plugin->load() == 0)
                {
                    std::string plugin_name = plugin->name();
                    loaded_module_list.push_back(plugin_name);
                    handles.push_back(handle);
                    plugins.push_back(plugin);
                }
                else
                {
                    plugin->unload();
                    dlclose(handle);
                    failed_module_list.push_back(entry.path().string());
                }
            }
        }
    }
}

void PluginLoader::unload()
{
    for (unsigned int i = 0; i < handles.size(); ++i)
    {
        module_exit mexit = reinterpret_cast<module_exit> (dlsym(handles[i], "module_exit"));
        if (mexit)
        {
            AbstractPlugin *plugin = reinterpret_cast<AbstractPlugin*>(plugins[i]);
            plugin->unload();
            mexit(plugins[i]);
        }
        dlclose(handles[i]);
    }

    handles.clear();
    plugins.clear();
    loaded_module_list.clear();
    failed_module_list.clear();
}

std::string PluginLoader::launch_module(unsigned int module_index, const std::string& parameter)
{
    AbstractPlugin *plugin = reinterpret_cast<AbstractPlugin*>(plugins[module_index]);
    std::string result = plugin->run(parameter);
    return result;
}

PluginLoader::~PluginLoader()
{
    this->unload();
}

std::vector<std::string> PluginLoader::failed_modules()
{
    return failed_module_list;
}

std::vector<std::string> PluginLoader::loaded_modules()
{
    return loaded_module_list;
}
