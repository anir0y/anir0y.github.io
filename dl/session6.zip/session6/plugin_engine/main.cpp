#include "pluginloader.hpp"

#include <iostream>
#include <string>

using namespace std;

int main(int argc, char** argv)
{
    std::string module_path = "../plugins/";
    PluginLoader loader(module_path);

    std::cout << "\n\nFailed modules: " << std::endl;
    for (std::string module : loader.failed_modules())
    {
        std::cout << module << std::endl;
    }

    std::string intermediate_result = "";

    while (true)
    {
        std::cout << std::endl << std::endl;

        std::cout << "\033[1;31mModules\033[0m" << std::endl;
        unsigned int i = 1, input = 0;
        for (std::string module : loader.loaded_modules())
        {
            std::cout <<"\t"<< i << ". " << module << std::endl;
            ++i;
        }

        std::cout <<"\t0. Exit" << std::endl;

        do
        {
            std::cout << "\t=> ";
            std::cin >> input;

            if (input == 0)
                return 0;
        } while (input >= i);

        char opt = '\0';

        if (intermediate_result != "")
        {
            std::cout << "Pass result from previous module [Y/N]? ";
            std::cin >> opt;
        }

        if (opt == 'Y' || opt == 'y')
            intermediate_result = loader.launch_module(input - 1, intermediate_result);
        else
            intermediate_result = loader.launch_module(input -1);
    }

    return 0;
}
