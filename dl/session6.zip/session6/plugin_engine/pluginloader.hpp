#ifndef PLUGINLOADER_HPP
#define PLUGINLOADER_HPP

#include "plugin_base.hpp"

#include <filesystem>
#include <string>
#include <unordered_map>
#include <vector>

class PluginLoader
{
private:
    std::string module_root;
    std::vector<std::string> loaded_module_list;
    std::vector<void*> handles;
    std::vector<void*> plugins;
    std::vector<std::string> failed_module_list;

    void load();
    void unload();
public:
    PluginLoader(std::string path);
    ~PluginLoader();
    std::vector<std::string> loaded_modules();
    std::vector<std::string> failed_modules();
    std::string launch_module(unsigned int module_index, const std::string& parameter = "");
};

#endif // PLUGINLOADER_HPP
