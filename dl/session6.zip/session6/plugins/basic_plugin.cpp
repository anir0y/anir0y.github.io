#include <iostream>
#include <string>

#include "plugin_base.hpp"

class DemoPlugin : public AbstractPlugin
{
public:
    DemoPlugin()
    {
        // constructor as needed
    }
    
    virtual ~DemoPlugin()
    {
        // destructor as needed
    }
    
    virtual int load()
    {
        return 0;
    }
    
    virtual int unload()
    {
        return 0;
    }
    
    virtual std::string name()
    {
        return std::string("Demo Plugin");
    }
    
    virtual std::string run(const std::string& parameter = "")
    {
        /*
         * parameter: the string is supposed to be parsed by module itself to extract parameters as suitable
         */
        
        std::cout << "Demo plugin has been executed." << std::endl;
        
        // return output serialized in text as suitable.
        return std::string("");
    }
};

extern "C"
{
void* module_init()
{
    DemoPlugin *obj = new DemoPlugin();
    return reinterpret_cast<void*>(obj);
}

void module_exit(void* ptr)
{
    if (ptr)
        delete reinterpret_cast<DemoPlugin*>(ptr);
}
}
